import classes from "./Projects.module.scss";

interface IProject {
  title: string;
  dates: string;
  description: string;
  imgSrc: string;
  techs: string[];
  github?: string;
  liveView?: string;
}

const projects: IProject[] = [
  {
    title: "EZMATMA",
    dates: "2022 – OBECNIE",
    description:
      "Projekt obejmował stworzenie platformy obsługującej odtwarzanie filmów, wyświetlanie notatek oraz śledzenie postępu użytkownika na podstawie rozwiązanych list zadań. Aplikacja posiada bazę użytkowników, automatyczne oraz manualne sprawdzanie list zadań oraz integrację z płatnościami internetowymi. W 2022 roku we współpracy z matematykiem stworzyłem aplikację oraz obsługiwałem projekt od strony technicznej. W tegorocznej edycji współpracuję z grafikiem oraz programistą, któremu przekazuję moją obecną wiedzę.",
    imgSrc: "media/projects/ezmatma.svg",
    techs: ["php", "js", "css"],
    liveView: "https://ezmatma.pl",
  },
  {
    title: "NOCOS SOLUTIONS",
    dates: "03.2024 - ??.????",
    description:
      "Razem z przyjaciółmi prowadzę mały zespół programistyczny. Mamy w planach stworzenie systemów i platform do nauki programoiwania dla dzieci i młodzieży. Czy nam to wyjdzie? Mam nadzieję, że tak i bardzo w to wierzę.",
    imgSrc: "media/projects/logo.jpeg",
    techs: ["figma", "vscode", "github", "stackoverflow"],
  },
  {
    title: "FAJRANT INATOR",
    dates: "01.2024",
    description:
      "W ramach przedmiotu na studia, w trzyosobowym zespole stworzyliśmy prosty sklep internetowy. Obsługuje on integracje z bazą danych, zakup produktu, dodawanie oraz usuwanie przedmiotów, zarządzanie użytkownikami oraz weryfikację sprzedającego.",
    imgSrc: "media/projects/fi.png",
    techs: ["js", "css"],
    liveView: "https://fi.nocos.pl",
    github: "https://github.com/PatrykFlama/FajrantInator.pl",
  },
  {
    title: "DOMOWY SERWER",
    dates: "12.2023",
    description:
      "Jestem fanem rozwiązań, które sprawiają, że mój dom jest \"smart\". Tak właśnie małymi krokami powstaje mój własny domowy serwer, który na ten moment obsługuje żarówkami, zasłonami i muzyką. W przyszłości chciałbym zautomatyzować dobór temperatury i stworzyć ładny wyświetlacz z wszystkimi danymi technicznymi domu, oraz innymi przydatnymi informacjami.",
    imgSrc: "media/projects/serwer.png",
    techs: ["bash", "docker", "linux"],
  },
  {
    title: "... TO PORTFOLIO!",
    dates: "04.2024",
    description:
      "Tak właściwie, to portfolio, które właśnie oglądasz, jest jedym z zadań, które wykonałem w ramach listy zadań na przedmiot poświęcony ractowi. To moje pierwsze spotkanie z routingiem i mam nadzieję, że nie ostatnie! PS. SCSS modules TOP",
    imgSrc: "media/projects/cv.png",
    techs: ["react", "ts", "scss", "vite"],
  },
  
];

function Projects() {
  return (
    <div className={classes.Projects}>
      {projects.map((project) => (
        <div className={classes.project}>
          <div className={classes.left}>
            {project.dates}
            <div className={classes.spacer}></div>
            <img src={project.imgSrc} />
            <div className={classes.spacer}> </div>
            <div className={classes.techs}>
              {project.techs.map((tech) => (
                <img src={`https://skillicons.dev/icons?i=${tech}`} />
              ))}
            </div>
          </div>

          <div className={classes.right}>
            <div className={classes.details}>
              <span className={classes.title}>{project.title}</span>
              <span className={classes.description}>{project.description}</span>
            </div>
            <div className={classes.links}>
              {project.github !== undefined ? (
                <a href={project.github} target="_blank">
                  <span className={classes.link}>Github</span>
                </a>
              ) : (
                ``
              )}
              {project.liveView !== undefined ? (
                <a href={project.liveView} target="_blank">
                  <span className={classes.link}>Live View</span>
                </a>
              ) : (
                ``
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Projects;
